//base by DGXeon
//recode by rizal-developer 
//YouTube: @rizal-developer
//Telegram: t.me/zal_x_u
//WhatsApp: 088213993436 / 083119115977
/// script gratis jangan di jual 😹
//*List panel privat*
//• 3GB = Rp.4000
//• 4GB = Rp.5000
//• 5GB = Rp.6000
//• 6GB = Rp.8000
//• 7GB = Rp.10000
//• 8GB = Rp.12000
//• 9GB = Rp.14000
//• 10Gb = Rp.15000
//• ∞/unlimited = Rp.15.000 

//*List panel public*
//•1gb = 1.000
//•2gb = 2.000
//•3gb = 3.000
//•4gb = 4.000
//•5gb = 5.000
//•6gb = 6.000
//•7gb = 7.000
//•8gb = 8.000
//•9gb = 9.000
//•10gb = Rp.10.000
//• ∞/unlimited = 14.000

//order  langsung pv : wa.me/6288213993436
//order2  langsung pv : wa.me/6283119115977
//tele : t.me/zal_x_u
//testi : https://t.me/testirizel
//YouTube : zal_x_u (rizal-dev)

//info : https://whatsapp.com/channel/0029Vaw0AGCEQIarHspllG1i


const fs = require('fs')
const chalk = require('chalk')

//owmner v card
global.ytname = "zal_x_u" //ur yt chanel name
global.socialm = "i dont have" //ur github or insta name
global.location = "singapore" //ur location

//new
global.botname = '𝗮𝗺𝗯𝗮𝘁𝘂𝗯𝗼𝘁' //ur bot name
global.ownernumber = '6283119115977' //ur owner number
global.ownername = 'rizal-dev' //ur owner name
global.websitex = "https://whatsapp.com/channel/0029Vaw0AGCEQIarHspllG1i"
global.wagc = "https://whatsapp.com/channel/0029Vaw0AGCEQIarHspllG1i"
global.themeemoji = '🪀'
global.wm = "rizal-dev"
global.botscript = 'https://www.youtube.com/@zal_x_u' //script link
global.packname = "𝗮𝗺𝗯𝗮𝘁𝘂𝗯𝗼𝘁"
global.author = "rizal-developer"
global.creator = "6283119115977@s.whatsapp.net"
global.xprefix = '.'
global.premium = ["6283119115977"] // Premium User
global.hituet = 0

//bot sett
global.typemenu = 'v8' // menu type 'v1' => 'v8'
global.typereply = 'v2' // reply type 'v1' => 'v3'
global.autoblocknumber = '' //set autoblock country code
global.antiforeignnumber = '' //set anti foreign number country code
global.welcome = true //welcome/left in groups
global.anticall = false //bot blocks user when called
global.autoswview = true //auto status/story view
global.adminevent = false //show promote/demote message
global.groupevent = false //show update messages in group chat
//msg
global.mess = {
	limit: 'Batas Anda telah habis!',
	nsfw: 'Nsfw dinonaktifkan di grup ini, Harap beri tahu admin untuk mengaktifkannya',
    done: 'Done✓',
    error: 'Error!',
    success: 'Succes'
}
//thumbnail
global.thumb = fs.readFileSync('./XeonMedia/theme/cheemspic.jpg')

let file = require.resolve(__filename)
fs.watchFile(file, () => {
    fs.unwatchFile(file)
    console.log(chalk.redBright(`Update'${__filename}'`))
    delete require.cache[file]
    require(file)
})